package model.agentsVégétaux;

import java.awt.Point;

public class Fleurs extends Vegetaux{
	
	
	
public Fleurs(Point coord) {
		super(coord);
		// TODO Auto-generated constructor stub
	}

public void PollenPlus() {
	if(this.pollen < 100) {
	this.pollen = this.pollen +10;
	}
}
public void cycle() {
	this.PollenPlus();
}


}

package model.agentsVégétaux;

import java.awt.Point;

import model.agents.Agent;

public class Vegetaux extends Agent{

	

	public int pollen;
	
	
	/**
	 * Createur d'un végétal avec ses coordonnées
	 * @param coord
	 */
	public Vegetaux(Point coord) {
		super(coord);
		this.pollen = 50;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Vegetaux " + this.getId() + " [pollen=" + pollen + "]";
	}
	

	
	
}


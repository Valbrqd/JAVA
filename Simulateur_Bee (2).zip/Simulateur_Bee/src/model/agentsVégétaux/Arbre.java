package model.agentsVégétaux;

import java.awt.Point;

public class Arbre extends Vegetaux{
public double taille;

	public Arbre(Point coord,double d) {
		super(coord);
		this.taille = d;
		// TODO Auto-generated constructor stub
	}
	
public void PollenPlus() {
	if(this.pollen < 10*Math.pow(2,this.taille)) {
		this.pollen = (int) (this.pollen + Math.pow(2,this.taille));
		
	}
}

public void cycle() {
	this.PollenPlus();
}

	
	
	
}

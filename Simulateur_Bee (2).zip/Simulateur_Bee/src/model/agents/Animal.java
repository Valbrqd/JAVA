package model.agents;

import java.awt.Point;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Objects;

import model.agentsVégétaux.Vegetaux;
import model.comportements.Deplacable;
import model.comportements.Hebergeur;


/**
 * Cette classe modélise un Animal dans la simulation
 * @author bruno
 *
 */
public class Animal extends Agent implements Deplacable{
	/** état de santé de l'animal */
	protected Etat etat;
	protected Sexe sexe;
	private int pollen;
	private Hebergeur hebergeur;
	
	
	/* 
	 * constructeurs 
	 */
	/**
	 * Constructeur d'un animal avec son sexe et ses coordonnees
	 * @param sexe
	 * @param coord
	 */
	public Animal(Sexe sexe, Point coord) {
		super(coord);
		this.sexe=sexe;
		this.etat=Etat.Normal;
	}
	
	/**
	 * Constructeur d'un animal avec son sexe
	 * @param sexe
	 */
	public Animal(Sexe sexe) {
		//TODO
		/* crée un animal avec le sexe passé en paramètre, à la position (0;0), d'âge 0 et lui attribue un id unique
		 * une bonne manière de faire 
		 * en utilisant ce qui existe déjà, une moins bonne
		 */
		this(sexe,new Point(0,0));
	}
	
	/**
	 * Constructeur d'animal par défaut
	 */
	public Animal() {
		//TODO
		/* crée un animal de sexe femelle, à la position (0;0), d'âge 0 et lui attribue un id unique
		 * une bonne manière de faire 
		 * en utilisant ce qui existe déjà, une moins bonne
		 */
		this(Sexe.Femelle);
	}
	/**
	 * Geter de l'Etat
	 * @return
	 */
	
	public void pasManger() {
		this.pollen = this.pollen-30;
	}
	
	public Etat getEtat() {
		return etat;
	}

	/**
	 * Geter du Sexe
	 * @return
	 */
	public Sexe getSexe() {
		return sexe;
	}
	
	/**
	 * Fonction qui permet de modifier l'emplacement des animaux 
	 */
	public void seDeplacer() {
		//TODO utiliser Math.random() pour choisir une direction de déplacement
		this.coord.x += tirageAleatoire();
		this.coord.y += tirageAleatoire();
	}
	
	/**
	 * Fonction qui permet d'obtenir un nombre aléatoire entre 0 et 2 (pas sur)
	 * @return
	 */
	private static int tirageAleatoire() {
		return  -1 +((int)(3*Math.random()));
	}
	
	/**
	 * condition d'installation d'un animal dans un hébergeur
	 * @param h
	 * @return
	 */
	protected final boolean sInstaller(Hebergeur h) {
		boolean ret=false;
		if(h!= null && h.accueillir(this)) {
			hebergeur = h;
			ret=true;
		}
		return ret;
	}
	 
	/*
	 * Redéfinitions de méthodes d'object
	 */
	//TODO
	
	public void aggraverEtat() {
		
	
		LinkedList<Etat> liste = new LinkedList<Etat>(Arrays.asList(Etat.values()));
	
		Iterator<Etat> it = liste.listIterator(liste.indexOf(etat));
		it.next(); // iterator se positionne juste avant notre etat 
		if(it.hasNext()) {
			etat = it.next();
		}
	
		
		
	}
	
	public void sefairemanger() {
		this.etat = Etat.Mourant;
	}
	
	public void appeuré() {
		this.etat = Etat.EnDetresse;
	}
	
	public void ameliorerEtat() {
		
		LinkedList<Etat> liste = new LinkedList<Etat>(Arrays.asList(Etat.values()));
		
		ListIterator<Etat> it = liste.listIterator(liste.indexOf(etat));
	
		if(it.hasPrevious() && etat!= Etat.Mourant) {
		
			etat = it.previous();
		}
		
	}
	
	public int getPollen() {
		return pollen;
	}

	public void setPollen(int pollen) {
		this.pollen = pollen;
	}

	/* 
	 * comportements d'instance
	 */
	public void seNourir(Agent a) {
		if(a instanceof Vegetaux) {
			if (this.etat != Etat.Mourant) {
				((Vegetaux) a).pollen -= 50; 	
				this.pollen += 50;
				
				this.ameliorerEtat();
			}
		}
	}



	@Override
	public String toString() {
		return this.getClass().getSimpleName()+" ,Id = " + this.getId() +  " (" + coord.x +";"+coord.y + "), " + sexe ;
	}

	
}

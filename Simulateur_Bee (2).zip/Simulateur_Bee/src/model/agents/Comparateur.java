package model.agents;

import java.util.Comparator;

public class Comparateur implements Comparator<Agent> {

	@Override
	public int compare(Agent o1, Agent o2) {
		
		int diffX = o1.coord.x - o2.coord.x;
		int diffY = o1.coord.y - o2.coord.y;
		if (diffX != 0) {
			return diffX;
		} else {
			if(diffY != 0) {
				return diffY;
			}
			else {
				return 0;
			}
		}
	

}
}

package model.agents;

import java.awt.Point;
import java.util.Objects;

public class Agent implements Comparable<Agent>{

	private static int currentId = 0;
	/** identifiant unique de l'animal*/
	private int id; 
	/** age en unité de temps*/
	protected int age;
	/** position sur la carte*/
	protected Point coord;
	
	/**
	 * Constructeur d'un agent avec les coordonnees
	 * @param coord
	 */
	public Agent(Point coord) {
		super();
		this.id = Agent.getUniqueId();
		this.age = 0;
		this.coord = coord;
	}
	
	
	
	/**
	 * Permet d'obtenir un nombre aléatoire entre -1 et 1
	 * @return
	 */
	private static int tirageAleatoire() {
		return  -1 +((int)(3*Math.random()));
	}
	/**
	 * Permet d'obtenir l'age de l'animal
	 * @return
	 */
	public int getAge() {
		return age;
	}
	/**
	 * Permet d'obtenir d'assigner un age à l'animal
	 * @return
	 */
	private void setAge(int newage) {
		if (newage > this.age && newage > 0) {
			this.age = newage;
		}	
	}

	/**
	 * Permet d'obtenir l'Id de l'animal
	 * @return
	 */
	public int getId() {
		return id;
	}
	/**
	 * Permet d'obtenir es coordonnées de l'animal
	 * @return
	 */
	public Point getCoord() {
		return coord.getLocation();
	}
	/**
	 * Permet d'obtenir de déplacer l'animal
	 * @return
	 */
	public void seDeplacer() {
		//TODO utiliser Math.random() pour choisir une direction de déplacement
		this.coord.x += tirageAleatoire();
		this.coord.y += tirageAleatoire();
	}

	/**
	 * Renvoie un identifiant unique non encore utilisé
	 * @return un identifiant entier unique d'animal
	 */
	protected static int getUniqueId() {
		//TODO
		Agent.currentId += 1;
		return (Agent.currentId);	
	}
	/**
	 * Permet d'obtenir de faire viellir l'animal d'une unité de temps
	 * @return
	 */
	public void vieillir() {
		//TODO fait vieillir l'animal d'une unité de temps
		//une bonne manière de faire, une moins bonne...
		setAge(this.age + 1);
	}
	/**
	 * Permet de simuler la rencontre entre deux entitées
	 * @return
	 */
	public void rencontrer(Agent a) {
		//TODO
	}


	public void setCoord(int a,int b) {
		this.coord = new Point(a,b);
	}
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Agent other = (Agent) obj;
		return id == other.id;
	}


	@Override
	public int compareTo(Agent o) {
		if (o.getId() < this.getId()) {
			return 1;
		}
		if (o.getId()> this.getId()) {
			return -1;
		}
		else {
			return 0;
		}
			
	}



	

}
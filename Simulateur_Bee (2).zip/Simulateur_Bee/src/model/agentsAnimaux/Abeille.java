package model.agentsAnimaux;

import model.agents.Agent;
import model.agents.Animal;
import model.agents.Etat;
import model.comportements.Hebergeur;

public class Abeille extends Animal implements Hebergeur {
	
	//Etat de l'hébergeur
	public Varroa varrheb;
	

	
	/**
	 * Créateur d'une abeille par défaut avec une quantité de pollen et de necter initialement nulle
	 */
public Abeille() {

	
}

public Varroa getVarrheb() {
	return varrheb;
}

public void polliniser() {
	
}


@Override
public boolean peutAccueillir(Agent a) {
	// TODO Auto-generated method stub
	if(a instanceof Varroa && varrheb == null && a.getCoord().equals(this.getCoord()) ) {
		return true;
	}
	else {
	return false;
	}
}

@Override
public boolean accueillir(Agent a) {
	// TODO Auto-generated method stub
	if(this.peutAccueillir(a)) {
		varrheb = (Varroa)a;
		return true;
	}
	else {
	return false;
	}
}


/**
 * Rencontre avec varroa
 * @param a
 */
public void renconter(Agent a) {
	if(a instanceof Varroa) {
		this.accueillir(a);
	}
}

@Override
public String toString() {
	return this.getClass().getSimpleName()+" ,Id = " + this.getId() +  " (" + coord.x +";"+coord.y + "), " + sexe + " | Herberge : " + this.getVarrheb()+", "+ this.etat;
}





}
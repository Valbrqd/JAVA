package model.agentsAnimaux;

import java.awt.Point;

import model.agents.Sexe;

public class AbeilleSol extends Abeille{

	public AbeilleSol(Sexe sexe, Point coord) {
		// TODO Auto-generated constructor stub
		this.sexe = sexe;
		this.coord = coord;
	}
	
	public void cycle(){
		this.seDeplacer();
	}
	
}

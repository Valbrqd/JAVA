package model.agentsAnimaux;

import java.awt.Point;

import model.agents.Agent;
import model.agents.Animal;
import model.agents.Sexe;

public class Varroa extends Animal{

	
	
	
public Varroa(Sexe sexe, Point coord) {
		// TODO Auto-generated constructor stub
	this.sexe = sexe;
	this.coord = coord;
	
	}

public void rencontrer(Agent a) {
	if(a instanceof Abeille) {
		((Abeille) a).accueillir(this);
		((Abeille)a).aggraverEtat();
	}
}

public void cycle(){
	this.seDeplacer();
}

}

package model.agentsAnimaux;

import java.awt.Point;

import model.agents.Sexe;
import model.decor.Ruche;

public class AbeilleDom extends Abeille{
	private Ruche ruche;
	
	
	/**
	 * Createur d'une abeille doméstique avec son ID de ruche
	 * @param IDr
	 */
	public AbeilleDom(Ruche ruche,Sexe sexe) {
		this.ruche = ruche;
		this.sexe = sexe;
	}

public AbeilleDom(Sexe sexe, Point coord, Ruche ruche) {
		// TODO Auto-generated constructor stub
	this.sexe = sexe;
	this.coord = coord;
	this.ruche = ruche;
}	
	
public void cycle(){
	this.seDeplacer();
}
	
}

package model.agentsAnimaux;

import java.awt.Point;

import model.agents.Agent;
import model.agents.Animal;
import model.agents.Etat;
import model.agents.Sexe;

public class FrelonsAs extends Frelons{

	
	


public FrelonsAs() {
	
}
	
	public FrelonsAs(Sexe sexe, Point coord) {
	// TODO Auto-generated constructor stub
		this.sexe = sexe;
		this.coord = coord;
}

	
}



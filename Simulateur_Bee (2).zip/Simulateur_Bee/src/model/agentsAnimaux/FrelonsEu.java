package model.agentsAnimaux;

import java.awt.Point;

import model.agents.Sexe;

public class FrelonsEu extends Frelons{

	public FrelonsEu(Sexe sexe, Point coord) {
		// TODO Auto-generated constructor stub
		this.sexe = sexe;
		this.coord = coord;
	}
	
public FrelonsEu() {
	proies.add(FrelonsAs.class);
}

}

package model.agentsAnimaux;

import java.util.ArrayList;

import model.agents.Agent;
import model.agents.Animal;



public class Frelons extends Animal{

	protected ArrayList<Class<? extends Animal>> proies;
	public boolean faim;

	
	/**
	 * Céateur par défauts pour les Frelons
	 */
public Frelons() {
	proies = new ArrayList<Class<? extends Animal>>();
	proies.add(Abeille.class);
	this.faim = false;
}


public boolean GestionProies(Agent a) {
	boolean GP = false;
	for (Class<? extends Animal> clazz : proies) {
		if(clazz.isAssignableFrom(a.getClass())) {
			GP =  true;
			break;
		}
	}
	return GP;	
}

public void rencontrer(Agent a) {
	
	if(GestionProies(a)) {

		Animal proie;

		if (a instanceof Animal) {
			proie = ((Animal)a);
			if(this.faim) {
				proie.sefairemanger();
				this.faim = false;
				ameliorerEtat();
			}
		
			else {
				proie.appeuré();
			}
		} else {
			throw new RuntimeException("Proie trouvée qui n'est pas un Animal");
		}
	}
}

public void pasManger() {
	
}

public void cycle(){
	this.seDeplacer();
}

	

}


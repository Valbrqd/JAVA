package model.decor;

public class Champ {

}

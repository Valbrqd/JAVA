package model.decor;

import java.awt.Point;
import java.util.HashSet;
import model.agents.Agent;
import model.agentsAnimaux.Abeille;
import model.agentsAnimaux.AbeilleDom;
import model.comportements.Hebergeur;

public class Ruche extends Decor implements Hebergeur{
	public static int popMax = 1000;
	public HashSet<Abeille> popAb; 

public Ruche(Point coord) {
	super(coord);
	popAb = new HashSet<Abeille>();
}
	
	@Override
	public boolean peutAccueillir(Agent a) {
		// TODO Auto-generated method stub
		if(popAb.size() < popMax  && a instanceof AbeilleDom) {
			return true;
		}
		else {
		return false;
		}
	}

	@Override
	public boolean accueillir(Agent a) {
		// TODO Auto-generated method stub
		if(this.peutAccueillir(a) && a instanceof AbeilleDom) {
			Abeille MonA = ((Abeille)a);
			popAb.add(MonA);
			
			return true;
		}
		else {
			
			return false;
		}
	}
	
	
	public String afficherAbeille() {
		String res = "";
		for (Abeille AB : popAb) {
			res += "\t" + AB.getClass().getSimpleName() +" "+ AB.getId() + " (" + coord.x +";"+coord.y + ") ," + AB.getSexe() +"\n";
		
		}
		return res;
	}
	
	public String toString() {
		return this.getClass().getSimpleName()+ " (" + coord.x +";"+coord.y + ") : "  + " Population "+ this.popAb.size() +" Abeille(s)\n" + this.afficherAbeille() ;
	}

	public int getpopMax() {
		return popMax;
	}

	@Override
	public boolean supprimerAnimal(Agent a) {
		// TODO Auto-generated method stub
		return false;
	}


	
}
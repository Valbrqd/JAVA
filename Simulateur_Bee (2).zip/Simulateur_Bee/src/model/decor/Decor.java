package model.decor;

import java.awt.Point;

import model.agents.Agent;

public class Decor {
	public Point coord;
	


public Decor(Point coord) {
	this.coord = coord;
}




}
package launchers;

import java.awt.Point;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import model.agents.Sexe;
import model.agentsAnimaux.Abeille;
import model.agentsAnimaux.AbeilleDom;
import model.agentsAnimaux.FrelonsAs;
import model.agentsAnimaux.Varroa;
import model.decor.Ruche;
import model.world.Monde;



public class Launcher {
	/*
	public static void main(String [] args) {
		Ruche r = new Ruche(new Point(0,0));
		Abeille a = new AbeilleDom(r,Sexe.Male);
		Abeille e = new AbeilleDom(r,Sexe.Male);
		FrelonsAs Fa = new FrelonsAs(Sexe.Male, new Point (0,0));
		
		
		
		//TODO
		//tester la hiérarchie d'agent
		
		
		//System.out.println(r);
		r.accueillir(a);
		r.accueillir(e);
		System.out.println(r);
	}
*/
	
	public static void main(String[] args) {
		
		ArrayList<Integer> Test = new ArrayList<>();
		Map<Integer,ArrayList<Integer>> test2 = new HashMap<>();
		
		System.out.println(Test);
		Test.add(5);
		Test.add(3);
		Test.add(9);
		
		
		for (Integer entier : Test) {
			test2.put(entier, null);
			if(test2.get(5) == null) {
				test2.put(5, new ArrayList<Integer>());
				test2.get(5).add(6);
			}
		}
		
		System.out.println(test2);
		
		
		Monde m = new Monde(50);
		System.out.println(m);
		System.out.println("===================");
		m.cycle();
		System.out.println(m.gererRencontre());
		System.out.println(m);
		
	}
	

}

